Reel — Cinema theme
A single-file portfolio for filmmakers, editors, and motion designers.

WHAT IS IN THIS FOLDER
  index.html   the whole site: HTML, CSS, and a little JavaScript in one file
  README.txt   this file

EDIT THE TEXT
1. Open index.html in any plain-text editor (VS Code, Sublime, Notepad, TextEdit in plain-text mode).
2. The top of the file has a HOW TO EDIT comment that walks through the page.
3. Replace every value marked data-field="...": your name, role, projects, email, and links.
   Sample names, companies, and projects are fictional.
4. Sections in this template: Video hero, Selected work, Credits, Stills, Contact.
   Each repeating block (a project, a job, a quote) is wrapped in a comment that says how to copy it.
5. Update the <title> and the two meta descriptions near the top; search engines and link previews read them.

COLOR THEMES
This copy is set to the "cinema" theme. The same file also contains: "daylight" (Daylight).
To switch, change data-theme="cinema" on the <html> tag at the top of index.html.
Every color lives in the :root and [data-theme] blocks at the start of the <style> tag, so you can
also edit a theme or add your own.

NOTES FOR THIS TEMPLATE
- The hero holds a placeholder. Replace the <div class="video-placeholder"> with a YouTube or Vimeo <iframe>; the exact embed code to paste is in a comment right above it.
- Stills are colored frames. Replace each with an <img> or a background-image, as in the Plate template.

PREVIEW
Double-click index.html to open it in a browser. Fonts load from Google Fonts, so the first look
needs a network connection. You can also preview another theme without editing by opening
index.html?theme=daylight in the browser.

PUBLISH
Upload this folder to any static host. The entry file is index.html.
- GitHub Pages: create a repository, upload the files, then Settings > Pages > branch main, folder /.
- Netlify or Cloudflare Pages: drag the folder onto the dashboard.
