Dispatch — Newsprint theme
A single-file portfolio for journalists, essayists, and newsletter writers.

WHAT IS IN THIS FOLDER
  index.html   the whole site: HTML, CSS, and a little JavaScript in one file
  README.txt   this file

EDIT THE TEXT
1. Open index.html in any plain-text editor (VS Code, Sublime, Notepad, TextEdit in plain-text mode).
2. The top of the file has a HOW TO EDIT comment that walks through the page.
3. Replace every value marked data-field="...": your name, role, projects, email, and links.
   Sample names, companies, and projects are fictional.
4. Sections in this template: Dateline, Hero, Beats, Clippings, Newsletter, Contact.
   Each repeating block (a project, a job, a quote) is wrapped in a comment that says how to copy it.
5. Update the <title> and the two meta descriptions near the top; search engines and link previews read them.

COLOR THEMES
This copy is set to the "newsprint" theme. The same file also contains: "broadsheet" (Broadsheet).
To switch, change data-theme="newsprint" on the <html> tag at the top of index.html.
Every color lives in the :root and [data-theme] blocks at the start of the <style> tag, so you can
also edit a theme or add your own.

NOTES FOR THIS TEMPLATE
- Each clipping is an <article class="clip"> with outlet, date, headline link, and a one-line description. Newest first is the convention.
- The newsletter button links to a URL; point it at your Substack, Buttondown, or Ghost page.

PREVIEW
Double-click index.html to open it in a browser. Fonts load from Google Fonts, so the first look
needs a network connection. You can also preview another theme without editing by opening
index.html?theme=broadsheet in the browser.

PUBLISH
Upload this folder to any static host. The entry file is index.html.
- GitHub Pages: create a repository, upload the files, then Settings > Pages > branch main, folder /.
- Netlify or Cloudflare Pages: drag the folder onto the dashboard.
