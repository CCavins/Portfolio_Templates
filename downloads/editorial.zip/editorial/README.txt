This folder is ready to edit and deploy.

1. Open index.html in any text editor.
2. Replace every value marked data-field: your name, role, projects, email, and links.
   Sample names and projects are fictional.
3. Preview by opening index.html in a browser. Fonts load from Google Fonts, so you need a network connection for the first look.
4. Upload this folder to GitHub Pages (branch main, folder /), Netlify, Cloudflare Pages, or any static host.
   The entry file is index.html.

Photography template only: replace a frame's background with your own image, for example
style="background-image: url('photos/coast.jpg')", and put the image in a photos folder next to index.html.
